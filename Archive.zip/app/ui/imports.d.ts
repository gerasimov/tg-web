declare module '*.png';

declare module '*.svg';

declare module '*.less';

declare module '*.json';

declare module 'mtproto-client' {
  export default any;
}
