import "./checkbox.less";

export { default } from "./checkbox";
