import './input.less';

export { default } from './input';
