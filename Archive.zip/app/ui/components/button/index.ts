import "./button.less";

export { default } from "./button";
