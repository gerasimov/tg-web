declare namespace JSX {
  interface IntrinsicElements {
    [key: string]: any;
  }
}
